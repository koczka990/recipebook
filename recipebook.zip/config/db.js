const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/rr2fjm');

module.exports = mongoose;