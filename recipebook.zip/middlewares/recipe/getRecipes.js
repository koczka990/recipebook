/**
 * returns all existing recipe from the database in form of a list
 */

 module.exports = function (objectrepository) {
    return function (req, res, next) {
        return next();
    };
};