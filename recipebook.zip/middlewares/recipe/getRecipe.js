/**
 * returns an existing recipe specified by :recipeid
 */

 module.exports = function (objectrepository) {
    return function (req, res, next) {
        return next();
    };
};