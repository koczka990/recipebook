/**
 * returns list of all existing ingredients
 */

 module.exports = function (objectrepository) {
    return function (req, res, next) {
        return next();
    };
};