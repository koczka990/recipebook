/**
 * returns specific ingredient specified by :ingredientid
 */

 module.exports = function (objectrepository) {
    return function (req, res, next) {
        return next();
    };
};