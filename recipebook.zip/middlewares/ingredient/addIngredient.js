/**
 * adds new ingredient to existning recipe
 */

module.exports = function (objectrepository) {
    return function (req, res, next) {
        return next();
    };
};