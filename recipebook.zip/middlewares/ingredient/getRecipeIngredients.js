/**
 * returns all ingredients included by specified recipe
 */

 module.exports = function (objectrepository) {
    return function (req, res, next) {
        return next();
    };
};