/**
 * creates new recipe and saves it to database
 */

 module.exports = function (objectrepository) {
    return function (req, res, next) {
        return next();
    };
};